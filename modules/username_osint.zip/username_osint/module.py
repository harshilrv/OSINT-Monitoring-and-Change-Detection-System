from core.base_module import BaseModule
from core.models import Finding

from . import sherlock_code
from . import whatsmyname_code
from . import social_checker


class UsernameOSINTModule(BaseModule):

    name = "username_osint"
    supported_targets = ["username"]

    def run(self, target):

        findings = []

        username = target.strip()

        # ---------------------------
        # Sherlock
        # ---------------------------
        try:
            results = sherlock_code.run(username)

            for site in results or []:
                findings.append(
                    Finding(
                        type="username",
                        value=username,
                        source="sherlock",
                        target=target,
                        confidence=0.8,
                        metadata=site
                    )
                )

        except Exception:
            pass

        # ---------------------------
        # WhatsMyName
        # ---------------------------
        try:
            results = whatsmyname_code.run(username)

            for site in results or []:
                findings.append(
                    Finding(
                        type="username",
                        value=username,
                        source="whatsmyname",
                        target=target,
                        confidence=0.7,
                        metadata=site
                    )
                )

        except Exception:
            pass

        # ---------------------------
        # Social Checker
        # ---------------------------
        try:
            results = social_checker.run(username)

            for site in results or []:
                findings.append(
                    Finding(
                        type="username",
                        value=username,
                        source="social_checker",
                        target=target,
                        confidence=0.6,
                        metadata=site
                    )
                )

        except Exception:
            pass

        return findings