import requests

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}


def check_instagram(username):
    try:
        url = f"https://www.instagram.com/{username}/"
        r = requests.get(url, headers=headers, timeout=10)

        html = r.text.lower()

        not_found = [
            "sorry, this page isn’t available",
            "sorry, this page isn't available",
            "the link you followed may be broken",
        ]

        if not any(s in html for s in not_found):
            return {
                "platform": "instagram",
                "url": url,
                "exists": True
            }

    except:
        pass

    return None


def check_twitter(username):
    try:
        url = f"https://x.com/{username}"
        r = requests.get(url, headers=headers, timeout=10)

        text = r.text.lower()

        not_found = [
            "this account doesn’t exist",
            "this account doesn't exist",
            "account suspended",
        ]

        if not any(s in text for s in not_found):
            return {
                "platform": "twitter",
                "url": url,
                "exists": True
            }

    except:
        pass

    return None


def check_reddit(username):
    try:
        url = f"https://www.reddit.com/user/{username}/about.json"
        r = requests.get(url, headers=headers, timeout=8)

        if r.status_code == 200 and r.json().get("data", {}).get("name"):
            return {
                "platform": "reddit",
                "url": f"https://www.reddit.com/user/{username}",
                "exists": True
            }

    except:
        pass

    return None


def check_github(username):
    try:
        r = requests.get(f"https://api.github.com/users/{username}", timeout=8)

        if r.status_code == 200:
            return {
                "platform": "github",
                "url": f"https://github.com/{username}",
                "exists": True
            }

    except:
        pass

    return None


def check_linkedin(username):
    try:
        url = f"https://www.linkedin.com/in/{username}"
        r = requests.get(url, headers=headers, timeout=8)

        if r.status_code == 200 and "profile-not-found" not in r.text.lower():
            return {
                "platform": "linkedin",
                "url": url,
                "exists": True
            }

    except:
        pass

    return None


def check_youtube(username):
    try:
        url = f"https://www.youtube.com/@{username}"
        r = requests.get(url, headers=headers, timeout=8)

        if r.status_code == 200 and '"error"' not in r.text:
            return {
                "platform": "youtube",
                "url": url,
                "exists": True
            }

    except:
        pass

    return None


# =========================
# MAIN ENGINE FUNCTION
# =========================

def run(username):

    results = []

    checks = [
        check_instagram,
        check_twitter,
        check_reddit,
        check_github,
        check_linkedin,
        check_youtube
    ]

    for check in checks:
        res = check(username)
        if res:
            results.append(res)

    return results